﻿// Program 4
// CIS 199-XX
// Due: 4/25/2017
// By: Andrew L. Wright (Students use Grading ID)

// This file models the application logic for Program 4.
// It allows users to create GroundPackages and interact
// with the entered objects' data.

// Solution 1
// This solution uses typical nested if statements to
// perform validation in the Add Ground Package button
// click event handler.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog4
{
    public partial class Prog4Form : Form
    {
        public const int UOFL_ZIP = 40292; // UofL's zip code

        private List<GroundPackage> packageList = new List<GroundPackage>(); // List of packages

        // Precondition:  None
        // Postcondition: Program 4's form is ready to be shown
        public Prog4Form()
        {
            InitializeComponent();
        }

        // Precondition:  The Add button has been clicked
        // Postcondition: If valid data are entered, a ground package is created
        //                and its cost is displayed in list box
        private void addBtn_Click(object sender, EventArgs e)
        {
            GroundPackage gPackage; // The package
            int oZip;               // Package's origin zip
            int dZip;               // Package's destination zip
            double length;          // Package's length
            double width;           // Package's width
            double height;          // Package's height
            double weight;          // Package's weight
            double cost;            // Package's cost

            // Typical nested if statements for validation
            if (int.TryParse(originTxt.Text, out oZip) && oZip >= GroundPackage.MIN_ZIP &&
                oZip <= GroundPackage.MAX_ZIP)
            {
                if (int.TryParse(destTxt.Text, out dZip) && dZip >= GroundPackage.MIN_ZIP &&
    dZip <= GroundPackage.MAX_ZIP)
                {
                    if (double.TryParse(lengthTxt.Text, out length) && length > 0)
                    {
                        if (double.TryParse(widthTxt.Text, out width) && width > 0)
                        {
                            if (double.TryParse(heightTxt.Text, out height) && height > 0)
                            {
                                if (double.TryParse(weightTxt.Text, out weight) && weight > 0)
                                {
                                    // If get to this point in code, all entered data are valid
                                    // So create GroundPackage object (finally!)
                                    gPackage = new GroundPackage(oZip, dZip, length, width, height, weight); // Construct new package
                                    cost = gPackage.CalcCost();

                                    // Add package to list
                                    packageList.Add(gPackage);

                                    // Add package cost to ListBox
                                    packageListBox.Items.Add(cost.ToString("C"));

                                    ClearTextBoxes();
                                }
                                else
                                    MessageBox.Show("Enter a valid Weight!");
                            }
                            else
                                MessageBox.Show("Enter a valid Height!");
                        }
                        else
                            MessageBox.Show("Enter a valid Width!");
                    }
                    else
                        MessageBox.Show("Enter a valid Length!");
                }
                else
                    MessageBox.Show("Enter valid Destination Zip!");
            }
            else
                MessageBox.Show("Enter valid Origin Zip!");
        }

        // Precondition:  None
        // Postcondition: The selected package's details are displayed
        private void detailsBtn_Click(object sender, EventArgs e)
        {
            int index;              // Selected package's index
            GroundPackage gPackage; // Selected package

            index = packageListBox.SelectedIndex;
            if (index >= 0) // Valid index?
            {
                gPackage = packageList[index]; // Parallel position
                MessageBox.Show(gPackage.ToString());
            }
            else
            {
                MessageBox.Show("Must select package first!");
            }
        }

        // Precondition:  None
        // Postcondition: The selected package's destination zip is
        //                set to UofL's zip code
        private void toUofLBtn_Click(object sender, EventArgs e)
        {
            int index;              // Selected package's index
            GroundPackage gPackage; // Selected package
            double cost;            // Selected package's cost

            index = packageListBox.SelectedIndex;
            if (index >= 0) // Valid index?
            {
                gPackage = packageList[index]; // Parallel position
                gPackage.DestinationZip = UOFL_ZIP;
                cost = gPackage.CalcCost(); // Caclulate new cost

                // Update list box, too
                packageListBox.Items[index] = cost.ToString("C");

                MessageBox.Show("Destination Zip has been updated.");
            }
            else
            {
                MessageBox.Show("Must select package first!");
            }
        }

        // Precondition:  None
        // Postcondition: The selected package's origin zip is
        //                set to UofL's zip code
        private void fromUofLBtn_Click(object sender, EventArgs e)
        {
            int index;              // Selected package's index
            GroundPackage gPackage; // Selected package
            double cost;            // Selected package's cost

            index = packageListBox.SelectedIndex;
            if (index >= 0) // Valid index?
            {
                gPackage = packageList[index]; // Parallel position
                gPackage.OriginZip = UOFL_ZIP;
                cost = gPackage.CalcCost(); // Caclulate new cost

                // Update list box, too
                packageListBox.Items[index] = cost.ToString("C");

                MessageBox.Show("Origin Zip has been updated.");
            }
            else
            {
                MessageBox.Show("Must select package first!");
            }
        }

        // Precondition:  None
        // Postcondition: The form's textboxes have been cleared
        //                and focus set to the first one
        private void ClearTextBoxes()
        {
            originTxt.Clear();
            destTxt.Clear();
            lengthTxt.Clear();
            widthTxt.Clear();
            heightTxt.Clear();
            weightTxt.Clear();

            originTxt.Focus();
        }
    }
}
