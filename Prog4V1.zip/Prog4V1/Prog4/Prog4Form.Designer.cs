﻿namespace Prog4
{
    partial class Prog4Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.originLbl = new System.Windows.Forms.Label();
            this.destLbl = new System.Windows.Forms.Label();
            this.lengthLbl = new System.Windows.Forms.Label();
            this.widthLbl = new System.Windows.Forms.Label();
            this.heightLbl = new System.Windows.Forms.Label();
            this.weightLbl = new System.Windows.Forms.Label();
            this.originTxt = new System.Windows.Forms.TextBox();
            this.destTxt = new System.Windows.Forms.TextBox();
            this.lengthTxt = new System.Windows.Forms.TextBox();
            this.widthTxt = new System.Windows.Forms.TextBox();
            this.heightTxt = new System.Windows.Forms.TextBox();
            this.weightTxt = new System.Windows.Forms.TextBox();
            this.addBtn = new System.Windows.Forms.Button();
            this.packageListBox = new System.Windows.Forms.ListBox();
            this.detailsBtn = new System.Windows.Forms.Button();
            this.toUofLBtn = new System.Windows.Forms.Button();
            this.fromUofLBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // originLbl
            // 
            this.originLbl.AutoSize = true;
            this.originLbl.Location = new System.Drawing.Point(1, 13);
            this.originLbl.Name = "originLbl";
            this.originLbl.Size = new System.Drawing.Size(55, 13);
            this.originLbl.TabIndex = 0;
            this.originLbl.Text = "Origin Zip:";
            // 
            // destLbl
            // 
            this.destLbl.AutoSize = true;
            this.destLbl.Location = new System.Drawing.Point(3, 39);
            this.destLbl.Name = "destLbl";
            this.destLbl.Size = new System.Drawing.Size(53, 13);
            this.destLbl.TabIndex = 1;
            this.destLbl.Text = "Dest. Zip:";
            // 
            // lengthLbl
            // 
            this.lengthLbl.AutoSize = true;
            this.lengthLbl.Location = new System.Drawing.Point(13, 65);
            this.lengthLbl.Name = "lengthLbl";
            this.lengthLbl.Size = new System.Drawing.Size(43, 13);
            this.lengthLbl.TabIndex = 2;
            this.lengthLbl.Text = "Length:";
            // 
            // widthLbl
            // 
            this.widthLbl.AutoSize = true;
            this.widthLbl.Location = new System.Drawing.Point(18, 91);
            this.widthLbl.Name = "widthLbl";
            this.widthLbl.Size = new System.Drawing.Size(38, 13);
            this.widthLbl.TabIndex = 3;
            this.widthLbl.Text = "Width:";
            // 
            // heightLbl
            // 
            this.heightLbl.AutoSize = true;
            this.heightLbl.Location = new System.Drawing.Point(15, 117);
            this.heightLbl.Name = "heightLbl";
            this.heightLbl.Size = new System.Drawing.Size(41, 13);
            this.heightLbl.TabIndex = 4;
            this.heightLbl.Text = "Height:";
            // 
            // weightLbl
            // 
            this.weightLbl.AutoSize = true;
            this.weightLbl.Location = new System.Drawing.Point(12, 143);
            this.weightLbl.Name = "weightLbl";
            this.weightLbl.Size = new System.Drawing.Size(44, 13);
            this.weightLbl.TabIndex = 5;
            this.weightLbl.Text = "Weight:";
            // 
            // originTxt
            // 
            this.originTxt.Location = new System.Drawing.Point(63, 10);
            this.originTxt.Name = "originTxt";
            this.originTxt.Size = new System.Drawing.Size(100, 20);
            this.originTxt.TabIndex = 6;
            // 
            // destTxt
            // 
            this.destTxt.Location = new System.Drawing.Point(63, 36);
            this.destTxt.Name = "destTxt";
            this.destTxt.Size = new System.Drawing.Size(100, 20);
            this.destTxt.TabIndex = 7;
            // 
            // lengthTxt
            // 
            this.lengthTxt.Location = new System.Drawing.Point(63, 62);
            this.lengthTxt.Name = "lengthTxt";
            this.lengthTxt.Size = new System.Drawing.Size(100, 20);
            this.lengthTxt.TabIndex = 8;
            // 
            // widthTxt
            // 
            this.widthTxt.Location = new System.Drawing.Point(63, 88);
            this.widthTxt.Name = "widthTxt";
            this.widthTxt.Size = new System.Drawing.Size(100, 20);
            this.widthTxt.TabIndex = 9;
            // 
            // heightTxt
            // 
            this.heightTxt.Location = new System.Drawing.Point(63, 114);
            this.heightTxt.Name = "heightTxt";
            this.heightTxt.Size = new System.Drawing.Size(100, 20);
            this.heightTxt.TabIndex = 10;
            // 
            // weightTxt
            // 
            this.weightTxt.Location = new System.Drawing.Point(63, 140);
            this.weightTxt.Name = "weightTxt";
            this.weightTxt.Size = new System.Drawing.Size(100, 20);
            this.weightTxt.TabIndex = 11;
            // 
            // addBtn
            // 
            this.addBtn.Location = new System.Drawing.Point(4, 181);
            this.addBtn.Name = "addBtn";
            this.addBtn.Size = new System.Drawing.Size(159, 23);
            this.addBtn.TabIndex = 12;
            this.addBtn.Text = "Add Ground Package";
            this.addBtn.UseVisualStyleBackColor = true;
            this.addBtn.Click += new System.EventHandler(this.addBtn_Click);
            // 
            // packageListBox
            // 
            this.packageListBox.FormattingEnabled = true;
            this.packageListBox.Location = new System.Drawing.Point(187, 13);
            this.packageListBox.Name = "packageListBox";
            this.packageListBox.Size = new System.Drawing.Size(160, 147);
            this.packageListBox.TabIndex = 13;
            // 
            // detailsBtn
            // 
            this.detailsBtn.Location = new System.Drawing.Point(354, 13);
            this.detailsBtn.Name = "detailsBtn";
            this.detailsBtn.Size = new System.Drawing.Size(75, 36);
            this.detailsBtn.TabIndex = 14;
            this.detailsBtn.Text = "Details";
            this.detailsBtn.UseVisualStyleBackColor = true;
            this.detailsBtn.Click += new System.EventHandler(this.detailsBtn_Click);
            // 
            // toUofLBtn
            // 
            this.toUofLBtn.Location = new System.Drawing.Point(354, 68);
            this.toUofLBtn.Name = "toUofLBtn";
            this.toUofLBtn.Size = new System.Drawing.Size(75, 36);
            this.toUofLBtn.TabIndex = 15;
            this.toUofLBtn.Text = "Send to UofL";
            this.toUofLBtn.UseVisualStyleBackColor = true;
            this.toUofLBtn.Click += new System.EventHandler(this.toUofLBtn_Click);
            // 
            // fromUofLBtn
            // 
            this.fromUofLBtn.Location = new System.Drawing.Point(354, 123);
            this.fromUofLBtn.Name = "fromUofLBtn";
            this.fromUofLBtn.Size = new System.Drawing.Size(75, 36);
            this.fromUofLBtn.TabIndex = 16;
            this.fromUofLBtn.Text = "Send from UofL";
            this.fromUofLBtn.UseVisualStyleBackColor = true;
            this.fromUofLBtn.Click += new System.EventHandler(this.fromUofLBtn_Click);
            // 
            // Prog4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(443, 216);
            this.Controls.Add(this.fromUofLBtn);
            this.Controls.Add(this.toUofLBtn);
            this.Controls.Add(this.detailsBtn);
            this.Controls.Add(this.packageListBox);
            this.Controls.Add(this.addBtn);
            this.Controls.Add(this.weightTxt);
            this.Controls.Add(this.heightTxt);
            this.Controls.Add(this.widthTxt);
            this.Controls.Add(this.lengthTxt);
            this.Controls.Add(this.destTxt);
            this.Controls.Add(this.originTxt);
            this.Controls.Add(this.weightLbl);
            this.Controls.Add(this.heightLbl);
            this.Controls.Add(this.widthLbl);
            this.Controls.Add(this.lengthLbl);
            this.Controls.Add(this.destLbl);
            this.Controls.Add(this.originLbl);
            this.Name = "Prog4";
            this.Text = "Program 4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label originLbl;
        private System.Windows.Forms.Label destLbl;
        private System.Windows.Forms.Label lengthLbl;
        private System.Windows.Forms.Label widthLbl;
        private System.Windows.Forms.Label heightLbl;
        private System.Windows.Forms.Label weightLbl;
        private System.Windows.Forms.TextBox originTxt;
        private System.Windows.Forms.TextBox destTxt;
        private System.Windows.Forms.TextBox lengthTxt;
        private System.Windows.Forms.TextBox widthTxt;
        private System.Windows.Forms.TextBox heightTxt;
        private System.Windows.Forms.TextBox weightTxt;
        private System.Windows.Forms.Button addBtn;
        private System.Windows.Forms.ListBox packageListBox;
        private System.Windows.Forms.Button detailsBtn;
        private System.Windows.Forms.Button toUofLBtn;
        private System.Windows.Forms.Button fromUofLBtn;
    }
}

